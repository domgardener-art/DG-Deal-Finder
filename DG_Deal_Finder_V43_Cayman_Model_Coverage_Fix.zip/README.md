# DG Deal Finder V43 — Cayman / Model Coverage Fix

Fixes the DfT naming mismatch where `718 CAYMAN` did not match user-facing `Cayman`. Cayman ↔ 718 Cayman and Boxster ↔ 718 Boxster now resolve to the same official rows. Porsche core models remain visible while year-specific specs and spec-specific engines stay constrained.

Runtime regression proves `PORSCHE 718 CAYMAN` appears as Cayman and returns 2019 Cayman S/GTS specs plus the supported 2.5L engine.

100/100 targeted checks passed; runtime regression and compile/AST passed.
